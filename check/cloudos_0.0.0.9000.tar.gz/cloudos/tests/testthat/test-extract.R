test_that("dummy test - length computed correctly", {
  expect_success(expect_length(1, 1))
})