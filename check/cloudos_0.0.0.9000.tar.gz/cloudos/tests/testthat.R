library(testthat)
library(cloudos)

test_check("cloudos")
